from .src.cle_solve_func import(
    Model,
    euler_maruyama,
    solve_cle
)